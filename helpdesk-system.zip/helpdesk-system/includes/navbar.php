<nav class="navbar navbar-inverse">
	<div class="container-fluid">		
		<ul class="nav navbar-nav navbar">
			<li id="index"><a href="index.php" class="navbar-brand">Home</a></li>
			<?php if(isset($_SESSION["admin"])) { ?>
				<li id="ticket"><a href="ticket.php" >Ticket</a></li>
				<li id="department"><a href="department.php" >Department</a></li>
				<li id="user"><a href="user.php" >Users</a></li>				
			<?php } ?>						
		</ul>
		<ul class="nav navbar-nav navbar-right">
			<li class="dropdown">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="label label-pill label-danger count"></span> 
				<?php// echo md5($user['email']); ?>&nbsp;<?php if(isset($_SESSION["userid"])) { echo $user['username']; } ?><img src="//gravatar.com/avatar/?s=100" width="20px"></a>
				<ul class="dropdown-menu">					
					<li><a href="logout.php">Logout</a></li>
				</ul>
			</li>
		</ul>
	</div>
</nav>