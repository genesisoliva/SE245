<?php 
include 'init.php'; 
if(!$users->isLoggedIn()) {
	header("Location: login.php");	
} /*else {
	header("Location: index.php");	
}*/
include('includes/top.php');
$user = $users->getUserInfo();
?>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>		
<link rel="stylesheet" href="css/dataTables.bootstrap.min.css" />
<script src="js/general.js"></script>
<link rel="stylesheet" href="css/style.css" />
<title>Document</title>
<?php include('includes/container.php');?>
<div class="container">	
	<div class="row home-sections">
	<h2></h2>	
	<?php include('includes/navbar.php'); ?>		
	</div> 
</div>	
<?php include('includes/footer.php');?>